package com.nurseq.quizapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
